import { VStack } from "@chakra-ui/react";

const TaskCard = () => {
  return <VStack width={"180px"} height={"180px"} bg={"black"}></VStack>;
};

export default TaskCard;
